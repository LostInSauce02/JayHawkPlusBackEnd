using System;
using System.Threading.Tasks;

namespace WebApplication1
{
    public interface Interface
    {
        Task<bool> validateUser(string username, string password);
        Task<bool> validateDoctor(string username, string password);
        Task<bool> validateAdmin(string username, string password);
        Task<bool> createUser(string username, string password, string firstname, string lastname);
        Task<bool> bookAppointment(string username, string date, string time, string doc_name, string speciality, string instructions);
        Task<bool> removeAppointment(string username, string appt_id);
        Task<String> getAppointments(string username);
        Task<String> getAppointmentsDoctor(string username);
        Task<String> getPatients();
        Task<String> getDoctors();
        Task<String> getAllAppointments();
        Task<String> getProfile(string username);
    }
}
