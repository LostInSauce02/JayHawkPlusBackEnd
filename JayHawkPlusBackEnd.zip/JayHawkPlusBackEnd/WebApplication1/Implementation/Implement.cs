using System;
using System.Threading.Tasks;
using System.Linq;
using System.Net.Mail;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;

namespace WebApplication1
{
    public class Implement : Interface
    {
        private readonly NutshellContext context;

        /*
         * Description: This method defines the constructor for the Implement class, where the private variable NutshellContext is defined
         * Parameters: NutshellContext
         * Return: None
         */
        public Implement(NutshellContext _context)
        {
            context = _context;
        }

        /*
         * Description: This method checks if the AUTH table has the given username and password
         * Parameters: string username and string password
         * Return: Boolean value if the given username and password is found
         */
        public async Task<bool> validateUser(string username, string password)
        {

            IQueryable<AuthDatabaseResponse> patient = from c in context.Auth
                                      where c.username == username && c.password == password
                                      select c;
                                      
            if(patient.Count() != 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        /*
         * Description: This method checks if the DOCTORS table has the given username and password
         * Parameters: string username and string password
         * Return: Boolean value if the given username and password is found
         */
        public async Task<bool> validateDoctor(string username, string password)
        {

            IQueryable<DoctorDatabaseResponse> doctor = from c in context.Doctors
                                                       where c.doc_username == username && c.doc_password == password
                                                       select c;

            if (doctor.Count() != 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        /*
         * Description: This method checks if the ADMINISTRATION table has the given username and password
         * Parameters: string username and string password
         * Return: Boolean value if the given username and password is found
         */
        public async Task<bool> validateAdmin(string username, string password)
        {

            IQueryable<AdminDatabaseResponse> admin = from c in context.Administration
                                                        where c.admin_username == username && c.admin_password == password
                                                        select c;

            if (admin.Count() != 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        /*
         * Description: This method adds a new user in the AUTH and PATIENTS tables with the given parameters
         * Parameters: string username, string password, string firstname, string lastname
         * Return: Boolean value if the given username and password is created
         */
        public async Task<bool> createUser(string username, string password, string firstname, string lastname)
        {

            AuthDatabaseResponse patient = new AuthDatabaseResponse()
            {
                username = username,
                password = password,
            };

            IQueryable<AuthDatabaseResponse> patientSearch = from c in context.Auth
                                                                where c.username == username
                                                                select c;

            if (patientSearch.Count() != 0)
            {
                return false;
            }
            else
            {
                var maxValue = 0;

                try
                {
                    maxValue = context.Auth.Max(x => x.patient_id);
                }
                catch(Exception e)
                {
                    maxValue = 0;
                }
                patient.patient_id = maxValue + 1;
                context.Auth.Add(patient);
                context.SaveChanges();

                PatientDatabaseResponse person = new PatientDatabaseResponse()
                {
                    patient_id = maxValue + 1,
                    patient_firstname = firstname,
                    patient_lastname = lastname
                };
                context.Patient.Add(person);
                context.SaveChanges();

                return true;
            }

        }

        /*
         * Description: This method adds a appointment in the APPOINTMENTS table with the given parameters
         * Parameters: string username, string date, string time, string doc_name, string speciality, and string instructions
         * Return: Boolean value if appointment has been created
         */
        public async Task<bool> bookAppointment(string username, string date, string time, string doc_name, string speciality, string instructions)
        {

            IQueryable<AuthDatabaseResponse> patientSearch = from c in context.Auth
                                                             where c.username == username
                                                             select c;


            if(patientSearch.Count() != 0)
            {
                var patient_id = patientSearch.First().patient_id;
                IQueryable<DoctorDatabaseResponse> doctorSearch = from d in context.Doctors
                                                                  where d.doc_name == doc_name
                                                                  select d;
                if(doctorSearch.Count() != 0)
                {

                    var doc_id = doctorSearch.First().doc_id;
                    var maxValue = 0;
                    AppointmentDatabaseResponse appt = new AppointmentDatabaseResponse()
                    {
                        patient_id = patient_id,
                        appt_date = date,
                        appt_time = time,
                        appt_notes = instructions,
                        doc_id = doc_id
                    };

                    try
                    {
                        var temp = from c in context.Appointment
                                    where c.patient_id == patient_id
                                    select c;

                        var temp2 = temp.Max(c => c.appt_id);
                        maxValue = temp2;
                    }
                    catch(Exception e)
                    {
                        maxValue = 0;
                    }
                    appt.appt_id = maxValue + 1;
                    context.Appointment.Add(appt);
                    context.SaveChanges();

                    string _recepient = patientSearch.First().username;
                    string _password = patientSearch.First().password;
                    try
                    {
                        SmtpClient client = new SmtpClient("smtp.office365.com");
                        client.Port = 587;
                        client.DeliveryMethod = SmtpDeliveryMethod.Network;
                        client.UseDefaultCredentials = false;
                        System.Net.NetworkCredential credentials = new System.Net.NetworkCredential("INSERT EMAIL", "INSERT PASSWORD");
                        client.EnableSsl = true;
                        client.Credentials = credentials;

                        MailMessage message = new MailMessage("EMAIL", _recepient);
                        message.Subject = "Confirmation of Appointment";
                        message.Body = "Date: " + appt.appt_date + " Time: " + appt.appt_time + " Doctor: " + doctorSearch.First().doc_name;
                        client.Send(message);

                    }
                    catch(Exception e)
                    {
                        
                    }


                    return true;
                }
                else
                {
                    return false;
                }

            }
            else
            {
                return false;
            }

            
        }

        /*
         * Description: This method gets appointments respective to the given username of the Patient
         * Parameters: string username
         * Return: JSON string of all of the appointments based on the given username
         */
        public async Task<String> getAppointments(string username)
        {
            IQueryable<AuthDatabaseResponse> patient = from c in context.Auth
                                                       where c.username == username
                                                       select c;

            if (patient.Count() != 0)
            {
                //context.Appointment.
                IEnumerable<AppointmentDatabaseResponse> appt = from c in context.Appointment
                                                                where c.patient_id == patient.First().patient_id
                                                                select c;
                var list = appt.Cast<AppointmentDatabaseResponse>().ToList();
                var list1 = new List<AppointmentResponse>();
                foreach(AppointmentDatabaseResponse a in list)
                {
                    IQueryable<DoctorDatabaseResponse> doctor = from c in context.Doctors
                                                                where c.doc_id == a.doc_id
                                                                select c;

                    AppointmentResponse r = new AppointmentResponse()
                    {
                        id = a.appt_id.ToString(),
                        text = doctor.First().doc_name,
                        start = String.Concat(a.appt_date.Where(c => !Char.IsWhiteSpace(c))) + "T" + String.Concat(a.appt_time.Where(c => !Char.IsWhiteSpace(c))) + ":00",
                        end = String.Concat(a.appt_date.Where(c => !Char.IsWhiteSpace(c))) + "T" + "16:00:00"

                    };
                    list1.Add(r);

                }
                
                String appts = Newtonsoft.Json.JsonConvert.SerializeObject(list1);
                return appts;
            }
            else
            {
                return null;
            }
        }

        /*
         * Description: This method gets appointments respective to the given username of the Doctor
         * Parameters: string username
         * Return: JSON string of all of the appointments based on the given username
         */
        public async Task<String> getAppointmentsDoctor(string username)
        {
            IQueryable<DoctorDatabaseResponse> doctor = from c in context.Doctors
                                                       where c.doc_username == username
                                                       select c;

            if (doctor.Count() != 0)
            {
                var result = context.Appointment.AsNoTracking().Where(c => c.doc_id == doctor.First().doc_id).Select(c => c);
                var list = result.Cast<AppointmentDatabaseResponse>().ToList();
                var list1 = new List<AppointmentResponse>();
                foreach(AppointmentDatabaseResponse a in list)
                {
                    IQueryable<PatientDatabaseResponse> patient = from c in context.Patient
                                                                where c.patient_id == a.patient_id
                                                                select c;

                    AppointmentResponse r = new AppointmentResponse()
                    {
                        id = a.appt_id.ToString(),
                        text = patient.First().patient_firstname + " " + patient.First().patient_lastname,
                        start = String.Concat(a.appt_date.Where(c => !Char.IsWhiteSpace(c))) + "T" + String.Concat(a.appt_time.Where(c => !Char.IsWhiteSpace(c))) + ":00",
                        end = String.Concat(a.appt_date.Where(c => !Char.IsWhiteSpace(c))) + "T" + "16:00:00"

                    };
                    list1.Add(r);

                }
                
                String appts = Newtonsoft.Json.JsonConvert.SerializeObject(list1);
                return appts;
            }
            else
            {
                return null;
            }
        }

        /*
         * Description: This method gets all of the patients from the PATIENTS table
         * Parameters: None
         * Return: JSON string of all of the patients in the PATIENTS table
         */
        public async Task<String> getPatients()
        {

            var result = context.Patient.AsNoTracking().Select(c => c);
            var list = result.Cast<PatientDatabaseResponse>().ToList();
            String patients = Newtonsoft.Json.JsonConvert.SerializeObject(list);
            return patients;
               
        }

        /*
         * Description: This method gets all of the doctors from the DOCTOR table
         * Parameters: string username
         * Return: JSON string of all of the doctors based on the given username
         */
        public async Task<String> getDoctors()
        {

            var result = context.Doctors.AsNoTracking().Select(c => c);
            var list = result.Cast<DoctorDatabaseResponse>().ToList();
            String doctors = Newtonsoft.Json.JsonConvert.SerializeObject(list);
            return doctors;

        }

        /*
        * Description: This method gets all of the appointments from the APPOINTMENTS table
        * Parameters: string username
        * Return: JSON string of all of the appointments based on the given username
        */
        public async Task<String> getAllAppointments()
        {

            var result = context.Appointment.AsNoTracking().Select(c => c);
            var list = result.Cast<AppointmentDatabaseResponse>().ToList();
            String appts = Newtonsoft.Json.JsonConvert.SerializeObject(list);
            return appts;

        }

        /*
        * Description: This method gets PATIENTS table information based on the given username
        * Parameters: string username
        * Return: JSON string of the patient information from PATIENTS table based onf given username
        */
        public async Task<String> getProfile(string username)
        {

            var result1 = context.Auth.AsNoTracking().Where(c => c.username == username).Select(c => c);
            var result2 = context.Patient.AsNoTracking().Where(c => c.patient_id == result1.First().patient_id).Select(c => c);

            Profile profile = new Profile()
            {
                firstname = result2.First().patient_firstname,
                lastname = result2.First().patient_lastname,
                username = result1.First().username,
                password = result1.First().password
            };
            List<Profile> profiles = new List<Profile>();
            profiles.Add(profile);
            
            String json = Newtonsoft.Json.JsonConvert.SerializeObject(profiles);
            return json;

        }

        /*
        * Description: This method removes appointment from APPOINTMENTS table based on given parameters
        * Parameters: string username, string appt_id
        * Return: Boolean value wheter appointment has been removed from the table
        */
        public async Task<bool> removeAppointment(string username, string appt_id)
        {

            IQueryable<AuthDatabaseResponse> patientSearch = from c in context.Auth
                                                             where c.username == username
                                                             select c;


            if (patientSearch.Count() != 0)
            {

                context.Database.ExecuteSqlInterpolated($"DELETE dbo.APPOINTMENTS WHERE patient_id = {patientSearch.First().patient_id} AND appt_id = {int.Parse(appt_id)}");
                context.SaveChanges();

                string _recepient = patientSearch.First().username;
                string _password = patientSearch.First().password;
                try
                {
                    SmtpClient client = new SmtpClient("smtp.office365.com");
                    client.Port = 587;
                    client.DeliveryMethod = SmtpDeliveryMethod.Network;
                    client.UseDefaultCredentials = false;
                    System.Net.NetworkCredential credentials = new System.Net.NetworkCredential("INSERT EMAIL", "INSERT PASSWORD");
                    client.EnableSsl = true;
                    client.Credentials = credentials;

                    MailMessage message = new MailMessage("EMAIL", _recepient);
                    message.Subject = "Cancellation of Appointment";
                    message.Body = "Appointment Has Been Cancelled!";
                    client.Send(message);

                }
                catch (Exception e)
                {

                }

                return true;

            }
            else
            {
                return false;
            }


        }
    }
}
