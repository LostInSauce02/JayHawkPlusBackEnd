using System;

namespace WebApplication1
{
    public class PatientRequest
    {
        public string username { get; set; }
        public string password { get; set; }

    }
}
