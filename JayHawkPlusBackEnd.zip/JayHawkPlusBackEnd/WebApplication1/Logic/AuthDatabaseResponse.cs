using System;

namespace WebApplication1
{
    public class AuthDatabaseResponse
    {
        public string username { get; set; }
        public string password { get; set; }
        public int patient_id { get; set; }

    }
}
