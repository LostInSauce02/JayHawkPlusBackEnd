using System;

namespace WebApplication1
{
    public class AdminRequest
    {
        public string username { get; set; }
        public string password { get; set; }

    }
}
