using System;

namespace WebApplication1
{
    public class DoctorDatabaseResponse
    {
        public int doc_id { get; set; }
        public string doc_username { get; set; }
        public string doc_name { get; set; }
        public string doc_password { get; set; }
        public string doc_speciality { get; set; }

    }
}
