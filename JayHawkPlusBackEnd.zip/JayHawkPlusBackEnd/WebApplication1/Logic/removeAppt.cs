using System;

namespace WebApplication1
{
    public class removeAppt
    {
        public string username { get; set; }
        public string appt_id { get; set; }
    }
}
