using System;
using System.ComponentModel.DataAnnotations;

namespace WebApplication1
{
    public class AppointmentDatabaseResponse
    {
        public int patient_id { get; set; }
        public int appt_id { get; set; }
        public string appt_date { get; set; }
        public string appt_time { get; set; }
        public string appt_notes { get; set; }
        public int doc_id { get; set; }

    }
}
