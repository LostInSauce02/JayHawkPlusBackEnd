using System;

namespace WebApplication1
{
    public class PatientDatabaseResponse
    {
        public int patient_id  { get; set; }
        public string patient_firstname { get; set; }
        public string patient_lastname { get; set; }

    }
}
