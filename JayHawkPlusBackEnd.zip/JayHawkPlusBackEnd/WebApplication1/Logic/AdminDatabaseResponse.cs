using System;
using System.ComponentModel.DataAnnotations;

namespace WebApplication1
{
    public class AdminDatabaseResponse
    {
        public int admin_id { get; set; }
        public string admin_username { get; set; }
        public string admin_password { get; set; }

    }
}
