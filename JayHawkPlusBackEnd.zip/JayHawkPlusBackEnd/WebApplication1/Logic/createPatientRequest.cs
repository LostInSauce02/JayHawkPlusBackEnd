using System;

namespace WebApplication1
{
    public class createPatientRequest
    {
        public string username { get; set; }
        public string password { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }

    }
}
