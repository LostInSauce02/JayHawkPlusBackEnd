using System;

namespace WebApplication1
{
    public class infoRequest
    {
        public string username { get; set; }
    }
}
