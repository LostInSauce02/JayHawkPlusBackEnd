using Microsoft.EntityFrameworkCore;
using System;

namespace WebApplication1
{
    public class NutshellContext : DbContext
    {
        public NutshellContext(DbContextOptions<NutshellContext> options): base(options) { }
        public virtual DbSet<AuthDatabaseResponse> Auth { get; set; }
        public virtual DbSet<PatientDatabaseResponse> Patient { get; set; }
        public virtual DbSet<AppointmentDatabaseResponse> Appointment { get; set; }
        public virtual DbSet<DoctorDatabaseResponse> Doctors { get; set; }
        public virtual DbSet<AdminDatabaseResponse> Administration { get; set; }

        /*
        * Description: This method gets defines the Entity Model for each table in the SQL Express Database
        * Parameters: ModelBuilder
        * Return: Nothing
        */
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AuthDatabaseResponse>().ToTable("AUTH").HasKey(c => c.username);
            modelBuilder.Entity<PatientDatabaseResponse>().ToTable("PATIENTS").HasKey(c => c.patient_id);
            modelBuilder.Entity<AppointmentDatabaseResponse>().ToTable("APPOINTMENTS").HasKey(c => c.appt_id).IsClustered();
            modelBuilder.Entity<DoctorDatabaseResponse>().ToTable("DOCTORS").HasKey(c => c.doc_id);
            modelBuilder.Entity<AdminDatabaseResponse>().ToTable("ADMINISTRATION").HasKey(c => c.admin_id);
        }
       
    }
}
