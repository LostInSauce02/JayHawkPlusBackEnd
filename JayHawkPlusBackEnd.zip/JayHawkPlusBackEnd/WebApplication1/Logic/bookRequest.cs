using System;

namespace WebApplication1
{
    public class bookRequest
    {
        public string username { get; set; }
        public string date { get; set; }
        public string time { get; set; }
        public string doc_name { get; set; }
        public string speciality { get; set; }
        public string instructions { get; set; }
    }
}
