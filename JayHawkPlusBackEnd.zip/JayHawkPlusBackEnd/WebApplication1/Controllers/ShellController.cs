﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ShellController : ControllerBase
    {

        private readonly ILogger<ShellController> _logger;
        private readonly Interface pinterface;

        /*
         * Description: This method is the the constructor for the ShellController Class, which initializes both a Logger and the Interface class that excecutes each method
         * Parameters: ILogger<ShellController> and Interface
         * Return: This method does not return anything
         */
        public ShellController(ILogger<ShellController> logger, Interface _interface)
        {
            _logger = logger;
            pinterface = _interface;
        }

        /*
         * Description: This method executes when an API call reaches this endpoint. The purpose of this method is to validate if the incoming user is in the database
         * Parameters: PatientRequest --> Comes from JSON body of the API call
         * Return: This method returns a boolean value whether the user is valid or not
         */
        [Route("/validateUser")]
        [HttpPost]
        public Task<bool> validateUser([FromBody] PatientRequest patient)
        {
            var result = pinterface.validateUser(patient.username, patient.password);
            return result;
        }

        /*
         * Description: This method executes when an API call reaches this endpoint. The purpose of this method is to validate if the incoming doctor is in the database
         * Parameters: DoctorRequest --> Comes from JSON body of the API call
         * Return: This method returns a boolean value whether the doctor is valid or not
         */
        [Route("/validateDoctor")]
        [HttpPost]
        public Task<bool> validateDoctor([FromBody] DoctorRequest doctor)
        {
            var result = pinterface.validateDoctor(doctor.username, doctor.password);
            return result;
        }

        /*
         * Description: This method executes when an API call reaches this endpoint. The purpose of this method is to validate if the incoming admin is in the database
         * Parameters: AdminRequest --> Comes from JSON body of the API call
         * Return: This method returns a boolean value whether the admin is valid or not
         */
        [Route("/validateAdmin")]
        [HttpPost]
        public Task<bool> validateAdmin([FromBody] AdminRequest admin)
        {
            var result = pinterface.validateAdmin(admin.username, admin.password);
            return result;
        }

        /*
         * Description: This method executes when an API call reaches this endpoint. The purpose of this method is create a user with the requested JSON info
         * Parameters: createPatientRequest --> Comes from JSON body of the API call
         * Return: This method returns a boolean value whether the user has successfully created and added to database
         */
        [Route("/Create")]
        [HttpPost]
        public Task<bool> create([FromBody] createPatientRequest patient)
        {
            var result = pinterface.createUser(patient.username, patient.password, patient.firstname, patient.lastname);
            return result;
        }

        /*
         * Description: This method executes when an API call reaches this endpoint. The purpose of this method is to create an appointment slot in the database with requested JSON info
         * Parameters: bookRequest --> Comes from JSON body of the API call
         * Return: This method returns a boolean value whether the appointment has been created and added to the database
         */
        [Route("/Book")]
        [HttpPost]
        public Task<bool> book([FromBody] bookRequest book)
        {
            var result = pinterface.bookAppointment(book.username, book.date, book.time, book.doc_name, book.speciality, book.instructions);
            return result;
        }

        /*
         * Description: This method executes when an API call reaches this endpoint. The purpose of this method is to remove an appointment in the database wth requested JSON info
         * Parameters: removeAppt --> Comes from JSON body of the API call
         * Return: This method returns a boolean value whether appointment has been removed from database
         */
        [Route("/Remove")]
        [HttpPost]
        public Task<bool> remove([FromBody] removeAppt remove)
        {
            var result = pinterface.removeAppointment(remove.username, remove.appt_id);
            return result;
        }

        /*
         * Description: This method executes when an API call reaches this endpoint. The purpose of this method is to retrieve all appointments from database based on given JSON info
         * Parameters: infoRequest --> Comes from JSON body of the API call
         * Return: This method returns a JSON string of all of the appointments that a specific user has created
         */
        [Route("/getAppointments")]
        [HttpGet]
        public Task<String> getAppointments([FromHeader] infoRequest patientAppt)
        {
            var result = pinterface.getAppointments(patientAppt.username);
            return result;
        }

        /*
         * Description: This method executes when an API call reaches this endpoint. The purpose of this method is to retrieve all appointments from database based on given JSON info
         * Parameters: infoRequest --> Comes from JSON body of the API call
         * Return: This method returns a JSON string of all of the appointments that a specific doctor has been included
         */
        [Route("/getAppointmentsDoctor")]
        [HttpGet]
        public Task<String> getAppointmentsDoctor([FromHeader] infoRequest doctorAppt)
        {
            var result = pinterface.getAppointmentsDoctor(doctorAppt.username);
            return result;
        }

        /*
         * Description: This method executes when an API call reaches this endpoint. The purpose of this method is to retrieve all patients from database
         * Parameters: None
         * Return: This method returns a JSON string of all of the patients in the database
         */
        [Route("/getPatients")]
        [HttpGet]
        public Task<String> getPatients()
        {
            var result = pinterface.getPatients();
            return result;
        }

        /*
         * Description: This method executes when an API call reaches this endpoint. The purpose of this method is to retrieve all doctors from database
         * Parameters: None
         * Return: This method returns a JSON string of all of the doctors in the database
         */
        [Route("/getDoctors")]
        [HttpGet]
        public Task<String> getDoctors()
        {
            var result = pinterface.getDoctors();
            return result;
        }

        /*
         * Description: This method executes when an API call reaches this endpoint. The purpose of this method is to retrieve all appointments from database
         * Parameters: None
         * Return: This method returns a JSON string of all of the appointments in the database
         */
        [Route("/getAllAppointments")]
        [HttpGet]
        public Task<String> getAllAppointments()
        {
            var result = pinterface.getAllAppointments();
            return result;
        }

        /*
         * Description: This method executes when an API call reaches this endpoint. The purpose of this method is to retrieve patient information based on JSON info
         * Parameters: infoRequest --> Comes from JSON body of the API call
         * Return: This method returns a JSON string of the patient information based on the given patient from the database
         */
        [Route("/getProfile")]
        [HttpPost]
        public Task<String> getProfile([FromBody] infoRequest patientprofile)
        {
            var result = pinterface.getProfile(patientprofile.username);
            return result;
        }
    }
}
