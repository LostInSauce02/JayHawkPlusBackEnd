﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ShellController : ControllerBase
    {

        private readonly ILogger<ShellController> _logger;
        private readonly Interface pinterface;

        public ShellController(ILogger<ShellController> logger, Interface _interface)
        {
            _logger = logger;
            pinterface = _interface;
        }

        [Route("/validateUser")]
        [HttpPost]
        public Task<bool> validateUser([FromBody] PatientRequest patient)
        {
            var result = pinterface.validateUser(patient.username, patient.password);
            return result;
        }

        [Route("/validateDoctor")]
        [HttpPost]
        public Task<bool> validateDoctor([FromBody] DoctorRequest doctor)
        {
            var result = pinterface.validateDoctor(doctor.username, doctor.password);
            return result;
        }

        [Route("/validateAdmin")]
        [HttpPost]
        public Task<bool> validateAdmin([FromBody] AdminRequest admin)
        {
            var result = pinterface.validateAdmin(admin.username, admin.password);
            return result;
        }

        [Route("/Create")]
        [HttpPost]
        public Task<bool> create([FromBody] createPatientRequest patient)
        {
            var result = pinterface.createUser(patient.username, patient.password, patient.firstname, patient.lastname);
            return result;
        }

        [Route("/Book")]
        [HttpPost]
        public Task<bool> book([FromBody] bookRequest book)
        {
            var result = pinterface.bookAppointment(book.username, book.date, book.time, book.doc_name, book.speciality, book.instructions);
            return result;
        }

        [Route("/Remove")]
        [HttpPost]
        public Task<bool> remove([FromBody] removeAppt remove)
        {
            var result = pinterface.removeAppointment(remove.username, remove.appt_id);
            return result;
        }

        [Route("/getAppointments")]
        [HttpGet]
        public Task<String> getAppointments([FromHeader] infoRequest patientAppt)
        {
            var result = pinterface.getAppointments(patientAppt.username);
            return result;
        }
        [Route("/getAppointmentsDoctor")]
        [HttpGet]
        public Task<String> getAppointmentsDoctor([FromHeader] infoRequest doctorAppt)
        {
            var result = pinterface.getAppointmentsDoctor(doctorAppt.username);
            return result;
        }

        [Route("/getPatients")]
        [HttpGet]
        public Task<String> getPatients()
        {
            var result = pinterface.getPatients();
            return result;
        }

        [Route("/getDoctors")]
        [HttpGet]
        public Task<String> getDoctors()
        {
            var result = pinterface.getDoctors();
            return result;
        }

        [Route("/getAllAppointments")]
        [HttpGet]
        public Task<String> getAllAppointments()
        {
            var result = pinterface.getAllAppointments();
            return result;
        }

        [Route("/getProfile")]
        [HttpPost]
        public Task<String> getProfile([FromBody] infoRequest patientprofile)
        {
            var result = pinterface.getProfile(patientprofile.username);
            return result;
        }
    }
}
